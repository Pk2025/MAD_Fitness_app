package com.example.fitnessapp1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
